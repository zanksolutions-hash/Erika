const menuButton = document.getElementById("menuButton");
const nav = document.getElementById("nav");

if (menuButton && nav) {
  menuButton.addEventListener("click", () => nav.classList.toggle("open"));
  nav.querySelectorAll("a").forEach(link => {
    link.addEventListener("click", () => nav.classList.remove("open"));
  });
}

const STORAGE_KEY = "erikaCasaArticles";

function escapeHTML(value = "") {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function formatDate(dateString) {
  if (!dateString) return "";
  const d = new Date(dateString + "T12:00:00");
  return new Intl.DateTimeFormat("fr-BE", {
    day: "numeric",
    month: "long",
    year: "numeric"
  }).format(d);
}

function getPublishedArticles() {
  try {
    const articles = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    return Array.isArray(articles)
      ? articles.filter(article => article && article.status === "published")
      : [];
  } catch {
    return [];
  }
}

function renderHomeArticles() {
  const container = document.getElementById("homeDynamicArticles");
  if (!container) return;

  const articles = getPublishedArticles()
    .sort((a, b) => String(b.date || "").localeCompare(String(a.date || "")))
    .slice(0, 3);

  if (!articles.length) {
    container.remove();
    return;
  }

  container.innerHTML = articles.map(article => {
    const meta = [formatDate(article.date), article.category]
      .filter(Boolean)
      .join(" · ");

    return `
      <a class="home-article-teaser dynamic-home-teaser"
         href="article-dynamique.html?id=${encodeURIComponent(article.id)}">
        <div>
          <p class="article-meta">${escapeHTML(meta)}</p>
          <h3>${escapeHTML(article.title)}</h3>
          <p>${escapeHTML(article.excerpt || "")}</p>
        </div>
        <span>Lire →</span>
      </a>
    `;
  }).join("");
}

renderHomeArticles();
